var searchData=
[
  ['defaultkey_0',['DefaultKey',['../classNini_1_1Config_1_1RegistryConfigSource.html#a3d3cfaa2b46c93c8056445603c9a34e8',1,'Nini::Config::RegistryConfigSource']]],
  ['dispose_1',['Dispose',['../classNini_1_1Ini_1_1IniReader.html#ace3bbf8ceed1e8bf8993f361e2ab612c',1,'Nini.Ini.IniReader.Dispose()'],['../classNini_1_1Ini_1_1IniReader.html#a57d9406c6f3f139470e249ab22d35e78',1,'Nini.Ini.IniReader.Dispose(bool disposing)'],['../classNini_1_1Ini_1_1IniWriter.html#ab23e2f5833fe26184a94c86add12714c',1,'Nini.Ini.IniWriter.Dispose()'],['../classNini_1_1Ini_1_1IniWriter.html#ad6bc33f2e8c677ea6d42daa3ba41bbbb',1,'Nini.Ini.IniWriter.Dispose(bool disposing)']]],
  ['dotnetconfigsource_2',['DotNetConfigSource',['../classNini_1_1Config_1_1DotNetConfigSource.html#a84c0833cd74a2d9b4b45145645dbe66d',1,'Nini.Config.DotNetConfigSource.DotNetConfigSource(string[] sections)'],['../classNini_1_1Config_1_1DotNetConfigSource.html#ae2b89e5994d98bc58a15748beb8597d0',1,'Nini.Config.DotNetConfigSource.DotNetConfigSource()'],['../classNini_1_1Config_1_1DotNetConfigSource.html#aa8231524608b50cbd2eaedaeecdf0091',1,'Nini.Config.DotNetConfigSource.DotNetConfigSource(string path)'],['../classNini_1_1Config_1_1DotNetConfigSource.html#a0d959cbde05de68f4c2d0c812c491511',1,'Nini.Config.DotNetConfigSource.DotNetConfigSource(XmlReader reader)'],['../classNini_1_1Config_1_1DotNetConfigSource.html',1,'Nini.Config.DotNetConfigSource']]],
  ['dotnetconfigsource_2ecs_3',['DotNetConfigSource.cs',['../DotNetConfigSource_8cs.html',1,'']]],
  ['dotnetconfigsourcetests_4',['DotNetConfigSourceTests',['../classNini_1_1Test_1_1Config_1_1DotNetConfigSourceTests.html',1,'Nini::Test::Config']]],
  ['dotnetconfigsourcetests_2ecs_5',['DotNetConfigSourceTests.cs',['../DotNetConfigSourceTests_8cs.html',1,'']]],
  ['dotnetconsoletests_6',['DotNetConsoleTests',['../classNini_1_1Test_1_1Config_1_1DotNetConsoleTests.html',1,'Nini::Test::Config']]],
  ['dotnetconsoletests_2ecs_7',['DotNetConsoleTests.cs',['../DotNetConsoleTests_8cs.html',1,'']]],
  ['duplicatekeys_8',['DuplicateKeys',['../classNini_1_1Test_1_1Ini_1_1IniDocumentTests.html#a8f92d8710155b845e1d8190029c7e693',1,'Nini::Test::Ini::IniDocumentTests']]],
  ['duplicatesections_9',['DuplicateSections',['../classNini_1_1Test_1_1Ini_1_1IniDocumentTests.html#a2a43a7cd6e19e0a482dae6afa3ca6bb3',1,'Nini::Test::Ini::IniDocumentTests']]]
];
