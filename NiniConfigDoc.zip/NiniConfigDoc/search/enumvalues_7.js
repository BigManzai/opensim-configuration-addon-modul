var searchData=
[
  ['mysqlstyle_0',['MysqlStyle',['../namespaceNini_1_1Ini.html#a29eef6be03bbf35390f62d17ef37fbe3a662276fb862e673c2a16836a0042e1ed',1,'Nini::Ini']]]
];
