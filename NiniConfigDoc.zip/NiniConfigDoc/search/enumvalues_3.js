var searchData=
[
  ['empty_0',['Empty',['../namespaceNini_1_1Ini.html#afa1d73fadec06e0c4abd6dc053b208e3ace2c8aed9c2fa0cfbed56cbda4d8bf07',1,'Nini::Ini']]],
  ['endoffile_1',['EndOfFile',['../namespaceNini_1_1Ini.html#a76d792652e41cb5e8fdb4afc086c19b0a9556e151da49cd4bcf0352857cb33509',1,'Nini::Ini']]],
  ['error_2',['Error',['../namespaceNini_1_1Ini.html#a76d792652e41cb5e8fdb4afc086c19b0a902b0d55fddef6f8d651fe1035b7d4bd',1,'Nini::Ini']]]
];
