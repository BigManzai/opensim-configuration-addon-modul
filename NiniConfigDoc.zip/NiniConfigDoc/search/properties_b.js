var searchData=
[
  ['readstate_0',['ReadState',['../classNini_1_1Ini_1_1IniReader.html#ac84079460a68a74197084f319c86a4fb',1,'Nini::Ini::IniReader']]]
];
