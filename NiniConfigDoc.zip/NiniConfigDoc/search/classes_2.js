var searchData=
[
  ['dotnetconfigsource_0',['DotNetConfigSource',['../classNini_1_1Config_1_1DotNetConfigSource.html',1,'Nini::Config']]],
  ['dotnetconfigsourcetests_1',['DotNetConfigSourceTests',['../classNini_1_1Test_1_1Config_1_1DotNetConfigSourceTests.html',1,'Nini::Test::Config']]],
  ['dotnetconsoletests_2',['DotNetConsoleTests',['../classNini_1_1Test_1_1Config_1_1DotNetConsoleTests.html',1,'Nini::Test::Config']]]
];
