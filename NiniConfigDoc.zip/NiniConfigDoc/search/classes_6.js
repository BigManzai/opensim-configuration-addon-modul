var searchData=
[
  ['registryconfigsource_0',['RegistryConfigSource',['../classNini_1_1Config_1_1RegistryConfigSource.html',1,'Nini::Config']]],
  ['registryconfigsourcetests_1',['RegistryConfigSourceTests',['../classNini_1_1Test_1_1Config_1_1RegistryConfigSourceTests.html',1,'Nini::Test::Config']]]
];
