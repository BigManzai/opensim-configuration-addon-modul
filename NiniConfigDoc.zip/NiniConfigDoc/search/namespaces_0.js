var searchData=
[
  ['config_0',['Config',['../namespaceNini_1_1Config.html',1,'Nini.Config'],['../namespaceNini_1_1Test_1_1Config.html',1,'Nini.Test.Config']]],
  ['env_1',['Env',['../namespaceNini_1_1Env.html',1,'Nini']]],
  ['ini_2',['Ini',['../namespaceNini_1_1Ini.html',1,'Nini.Ini'],['../namespaceNini_1_1Test_1_1Ini.html',1,'Nini.Test.Ini']]],
  ['nini_3',['Nini',['../namespaceNini.html',1,'']]],
  ['test_4',['Test',['../namespaceNini_1_1Test.html',1,'Nini']]],
  ['util_5',['Util',['../namespaceNini_1_1Test_1_1Util.html',1,'Nini.Test.Util'],['../namespaceNini_1_1Util.html',1,'Nini.Util']]]
];
