var searchData=
[
  ['linecontinuation_0',['LineContinuation',['../classNini_1_1Ini_1_1IniReader.html#ac89043fe602428774adfc77ce9428b96',1,'Nini::Ini::IniReader']]],
  ['linenumber_1',['LineNumber',['../classNini_1_1Ini_1_1IniException.html#a211203433c6b73b2e32948dd32e3c813',1,'Nini.Ini.IniException.LineNumber()'],['../classNini_1_1Ini_1_1IniReader.html#a88d6d97c981503d39751cd7c1073aa7a',1,'Nini.Ini.IniReader.LineNumber()']]],
  ['lineposition_2',['LinePosition',['../classNini_1_1Ini_1_1IniException.html#a20f8c1d2ab7ce37d92e0659f96215aa3',1,'Nini.Ini.IniException.LinePosition()'],['../classNini_1_1Ini_1_1IniReader.html#aee89319ab2114e9f3261a3695b4a55fe',1,'Nini.Ini.IniReader.LinePosition()']]]
];
