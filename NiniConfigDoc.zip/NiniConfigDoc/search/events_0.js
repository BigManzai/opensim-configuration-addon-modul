var searchData=
[
  ['configadded_0',['ConfigAdded',['../classNini_1_1Config_1_1ConfigCollection.html#a7249e22b79dfe48263f6688e24440ea9',1,'Nini::Config::ConfigCollection']]],
  ['configremoved_1',['ConfigRemoved',['../classNini_1_1Config_1_1ConfigCollection.html#a273de0899ba506f21069d01d7a732b09',1,'Nini::Config::ConfigCollection']]]
];
