var searchData=
[
  ['initial_0',['Initial',['../namespaceNini_1_1Ini.html#a76d792652e41cb5e8fdb4afc086c19b0a4f2a91e15af2631ff9424564b8a45fb2',1,'Nini::Ini']]],
  ['interactive_1',['Interactive',['../namespaceNini_1_1Ini.html#a76d792652e41cb5e8fdb4afc086c19b0a24b9b8c0634a40138e76b2fb86894698',1,'Nini::Ini']]]
];
