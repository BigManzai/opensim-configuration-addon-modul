var searchData=
[
  ['basestream_0',['BaseStream',['../classNini_1_1Ini_1_1IniWriter.html#a72f82108808b5df907d02dff5dfb7168',1,'Nini::Ini::IniWriter']]],
  ['basicorder_1',['BasicOrder',['../classNini_1_1Test_1_1Util_1_1OrderedListTests.html#a2a717eab27c73f3dd22c1fa026969b00',1,'Nini::Test::Util::OrderedListTests']]],
  ['beforefirstsection_2',['BeforeFirstSection',['../namespaceNini_1_1Ini.html#a545ba8227c553c394ac7648bae980c5ea8bff8cc37b8c408feab9f735b8d09a10',1,'Nini::Ini']]],
  ['booleanalias_3',['BooleanAlias',['../classNini_1_1Test_1_1Config_1_1ConfigBaseTests.html#a865c829aac5e714bbf694c7157e8f0bc',1,'Nini::Test::Config::ConfigBaseTests']]],
  ['booleanaliasnodefault_4',['BooleanAliasNoDefault',['../classNini_1_1Test_1_1Config_1_1ConfigBaseTests.html#ab72f7ae2e5a9692a610a07d64173a3b5',1,'Nini::Test::Config::ConfigBaseTests']]]
];
