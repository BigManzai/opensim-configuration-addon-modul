var searchData=
[
  ['defaultkey_0',['DefaultKey',['../classNini_1_1Config_1_1RegistryConfigSource.html#a3d3cfaa2b46c93c8056445603c9a34e8',1,'Nini::Config::RegistryConfigSource']]]
];
