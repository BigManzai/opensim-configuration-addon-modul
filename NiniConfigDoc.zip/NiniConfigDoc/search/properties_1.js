var searchData=
[
  ['basestream_0',['BaseStream',['../classNini_1_1Ini_1_1IniWriter.html#a72f82108808b5df907d02dff5dfb7168',1,'Nini::Ini::IniWriter']]]
];
