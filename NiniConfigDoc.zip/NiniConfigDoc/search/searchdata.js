var indexSectionsWithContent =
{
  0: "=abcdefgiklmnoprstuvwx",
  1: "acdeiorx",
  2: "n",
  3: "acdeiorx",
  4: "abcdefgiklmnoprstwx",
  5: "k",
  6: "ir",
  7: "=bcefikmnpsw",
  8: "abcdefiklmnrstuvw",
  9: "ckrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

