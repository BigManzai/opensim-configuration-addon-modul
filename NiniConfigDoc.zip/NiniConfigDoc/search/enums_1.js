var searchData=
[
  ['registryrecurse_0',['RegistryRecurse',['../namespaceNini_1_1Config.html#acec6f6cda46a176d202036251fe01d6e',1,'Nini::Config']]]
];
