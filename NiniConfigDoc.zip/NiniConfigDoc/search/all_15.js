var searchData=
[
  ['xmlconfigsource_0',['XmlConfigSource',['../classNini_1_1Config_1_1XmlConfigSource.html',1,'Nini.Config.XmlConfigSource'],['../classNini_1_1Config_1_1XmlConfigSource.html#a0425367f0b288afaf0e0c84b6886f95e',1,'Nini.Config.XmlConfigSource.XmlConfigSource()'],['../classNini_1_1Config_1_1XmlConfigSource.html#a5a2e444f1ba90605b60efc94bfefe133',1,'Nini.Config.XmlConfigSource.XmlConfigSource(string path)'],['../classNini_1_1Config_1_1XmlConfigSource.html#ae598f85d9b06bdd54aa37e8510de5997',1,'Nini.Config.XmlConfigSource.XmlConfigSource(XmlReader reader)']]],
  ['xmlconfigsource_2ecs_1',['XmlConfigSource.cs',['../XmlConfigSource_8cs.html',1,'']]],
  ['xmlconfigsourcetests_2',['XmlConfigSourceTests',['../classNini_1_1Test_1_1Config_1_1XmlConfigSourceTests.html',1,'Nini::Test::Config']]],
  ['xmlconfigsourcetests_2ecs_3',['XmlConfigSourceTests.cs',['../XmlConfigSourceTests_8cs.html',1,'']]]
];
