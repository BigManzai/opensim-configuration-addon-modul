var searchData=
[
  ['saved_0',['Saved',['../classNini_1_1Config_1_1ConfigSourceBase.html#ab491b93faaec75f75fa95a5f37ed9d4b',1,'Nini.Config.ConfigSourceBase.Saved()'],['../interfaceNini_1_1Config_1_1IConfigSource.html#abfbd6acaf701d64a08b98ee49b89b9b1',1,'Nini.Config.IConfigSource.Saved()']]]
];
