var searchData=
[
  ['closed_0',['Closed',['../namespaceNini_1_1Ini.html#a76d792652e41cb5e8fdb4afc086c19b0a03f4a47830f97377a35321051685071e',1,'Nini.Ini.Closed()'],['../namespaceNini_1_1Ini.html#a545ba8227c553c394ac7648bae980c5ea03f4a47830f97377a35321051685071e',1,'Nini.Ini.Closed()']]]
];
