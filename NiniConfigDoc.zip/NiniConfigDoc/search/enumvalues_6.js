var searchData=
[
  ['key_0',['Key',['../namespaceNini_1_1Ini.html#afa1d73fadec06e0c4abd6dc053b208e3a897356954c2cd3d41b221e3f24f99bba',1,'Nini::Ini']]]
];
