var searchData=
[
  ['usevaluequotes_0',['UseValueQuotes',['../classNini_1_1Ini_1_1IniWriter.html#a4e47c0dd45572c933455165274a55440',1,'Nini::Ini::IniWriter']]]
];
