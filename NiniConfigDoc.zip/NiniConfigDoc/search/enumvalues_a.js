var searchData=
[
  ['sambastyle_0',['SambaStyle',['../namespaceNini_1_1Ini.html#a29eef6be03bbf35390f62d17ef37fbe3a1ec70037ec75067dc749e0d3c7a4a604',1,'Nini::Ini']]],
  ['section_1',['Section',['../namespaceNini_1_1Ini.html#afa1d73fadec06e0c4abd6dc053b208e3ad2c24d59e0baff4d0155fbdf62590867',1,'Nini.Ini.Section()'],['../namespaceNini_1_1Ini.html#a545ba8227c553c394ac7648bae980c5ead2c24d59e0baff4d0155fbdf62590867',1,'Nini.Ini.Section()']]],
  ['standard_2',['Standard',['../namespaceNini_1_1Ini.html#a29eef6be03bbf35390f62d17ef37fbe3aeb6d8ae6f20283755b339c0dc273988b',1,'Nini::Ini']]],
  ['start_3',['Start',['../namespaceNini_1_1Ini.html#a545ba8227c553c394ac7648bae980c5eaa6122a65eaa676f700ae68d393054a37',1,'Nini::Ini']]]
];
