var searchData=
[
  ['xmlconfigsource_0',['XmlConfigSource',['../classNini_1_1Config_1_1XmlConfigSource.html#a0425367f0b288afaf0e0c84b6886f95e',1,'Nini.Config.XmlConfigSource.XmlConfigSource()'],['../classNini_1_1Config_1_1XmlConfigSource.html#a5a2e444f1ba90605b60efc94bfefe133',1,'Nini.Config.XmlConfigSource.XmlConfigSource(string path)'],['../classNini_1_1Config_1_1XmlConfigSource.html#ae598f85d9b06bdd54aa37e8510de5997',1,'Nini.Config.XmlConfigSource.XmlConfigSource(XmlReader reader)']]]
];
