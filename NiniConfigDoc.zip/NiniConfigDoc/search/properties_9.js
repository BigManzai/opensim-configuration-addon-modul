var searchData=
[
  ['message_0',['Message',['../classNini_1_1Ini_1_1IniException.html#a8b8c537dfaa4c78d817b2fb4694e5384',1,'Nini::Ini::IniException']]]
];
