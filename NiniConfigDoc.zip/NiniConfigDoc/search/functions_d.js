var searchData=
[
  ['parsererror_0',['ParserError',['../classNini_1_1Test_1_1Ini_1_1IniDocumentTests.html#a1a73cb42acf5ae63a1abf43dad14324b',1,'Nini::Test::Ini::IniDocumentTests']]],
  ['pythonstyledocument_1',['PythonStyleDocument',['../classNini_1_1Test_1_1Ini_1_1IniDocumentTests.html#aa634e997824ef86e00fa3e5f61dc362d',1,'Nini::Test::Ini::IniDocumentTests']]]
];
