var searchData=
[
  ['keyremoved_0',['KeyRemoved',['../classNini_1_1Config_1_1ConfigBase.html#aabd3486d33c636f5ccfa77314bffff04',1,'Nini.Config.ConfigBase.KeyRemoved()'],['../interfaceNini_1_1Config_1_1IConfig.html#adc3967dac738111e96a30afdd79eb4f1',1,'Nini.Config.IConfig.KeyRemoved()']]],
  ['keyset_1',['KeySet',['../classNini_1_1Config_1_1ConfigBase.html#a58f7c52cc0bfd42baf5a53e3a396e02c',1,'Nini.Config.ConfigBase.KeySet()'],['../interfaceNini_1_1Config_1_1IConfig.html#a1ad677a23aaf986731d1440bf144c0f7',1,'Nini.Config.IConfig.KeySet()']]]
];
