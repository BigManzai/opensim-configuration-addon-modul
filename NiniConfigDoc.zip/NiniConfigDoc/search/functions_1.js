var searchData=
[
  ['basicorder_0',['BasicOrder',['../classNini_1_1Test_1_1Util_1_1OrderedListTests.html#a2a717eab27c73f3dd22c1fa026969b00',1,'Nini::Test::Util::OrderedListTests']]],
  ['booleanalias_1',['BooleanAlias',['../classNini_1_1Test_1_1Config_1_1ConfigBaseTests.html#a865c829aac5e714bbf694c7157e8f0bc',1,'Nini::Test::Config::ConfigBaseTests']]],
  ['booleanaliasnodefault_2',['BooleanAliasNoDefault',['../classNini_1_1Test_1_1Config_1_1ConfigBaseTests.html#ab72f7ae2e5a9692a610a07d64173a3b5',1,'Nini::Test::Config::ConfigBaseTests']]]
];
