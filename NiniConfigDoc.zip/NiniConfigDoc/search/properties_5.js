var searchData=
[
  ['filetype_0',['FileType',['../classNini_1_1Ini_1_1IniDocument.html#a2bfa478fa051d8d1edc02c51f6e48fa6',1,'Nini::Ini::IniDocument']]]
];
