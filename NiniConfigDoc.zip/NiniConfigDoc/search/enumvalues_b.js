var searchData=
[
  ['windowsstyle_0',['WindowsStyle',['../namespaceNini_1_1Ini.html#a29eef6be03bbf35390f62d17ef37fbe3a0c4b6bfd9560f9a4fac9e806b40ddcc8',1,'Nini::Ini']]]
];
