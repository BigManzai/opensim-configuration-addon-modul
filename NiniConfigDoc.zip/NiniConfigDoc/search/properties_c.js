var searchData=
[
  ['savepath_0',['SavePath',['../classNini_1_1Config_1_1DotNetConfigSource.html#aa70d4f4aaf0677ff05b29d2d3097e322',1,'Nini.Config.DotNetConfigSource.SavePath()'],['../classNini_1_1Config_1_1IniConfigSource.html#ae49025f83fbbfd9a4309df125cdb3332',1,'Nini.Config.IniConfigSource.SavePath()'],['../classNini_1_1Config_1_1XmlConfigSource.html#aaf9fbb6ad506d15f5f238c4e5bda3f63',1,'Nini.Config.XmlConfigSource.SavePath()']]],
  ['sections_1',['Sections',['../classNini_1_1Ini_1_1IniDocument.html#a5bdefa55c056f655d6f7e85bc181a486',1,'Nini::Ini::IniDocument']]],
  ['synchronized_2',['Synchronized',['../classNini_1_1Env_1_1EnvMap.html#a182f266d347773167a5090bb81bb62f8',1,'Nini::Env::EnvMap']]],
  ['syncroot_3',['SyncRoot',['../classNini_1_1Config_1_1ConfigCollection.html#ae93624ef94132e901a864110722185aa',1,'Nini.Config.ConfigCollection.SyncRoot()'],['../classNini_1_1Ini_1_1IniSectionCollection.html#aeda3fd79e2f7f5afb11cfa13276df9df',1,'Nini.Ini.IniSectionCollection.SyncRoot()'],['../classNini_1_1Util_1_1OrderedList.html#aadc6271c99b104f61e8cfab1d3a935f1',1,'Nini.Util.OrderedList.SyncRoot()']]]
];
