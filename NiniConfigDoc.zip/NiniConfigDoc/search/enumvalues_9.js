var searchData=
[
  ['pythonstyle_0',['PythonStyle',['../namespaceNini_1_1Ini.html#a29eef6be03bbf35390f62d17ef37fbe3a661db1ac70fe627f44cf0144dea0d5f4',1,'Nini::Ini']]]
];
