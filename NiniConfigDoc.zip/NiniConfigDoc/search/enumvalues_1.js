var searchData=
[
  ['beforefirstsection_0',['BeforeFirstSection',['../namespaceNini_1_1Ini.html#a545ba8227c553c394ac7648bae980c5ea8bff8cc37b8c408feab9f735b8d09a10',1,'Nini::Ini']]]
];
