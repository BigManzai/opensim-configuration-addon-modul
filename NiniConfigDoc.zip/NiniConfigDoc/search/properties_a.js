var searchData=
[
  ['name_0',['Name',['../classNini_1_1Config_1_1ConfigBase.html#af2662a3976f367717ad481e98c00b801',1,'Nini.Config.ConfigBase.Name()'],['../interfaceNini_1_1Config_1_1IConfig.html#aee2fb688f9b4d7f1c89158f5f121f9c5',1,'Nini.Config.IConfig.Name()'],['../classNini_1_1Env_1_1EnvItem.html#af1678f78a1582a0211b7059a1cebf4a8',1,'Nini.Env.EnvItem.Name()'],['../classNini_1_1Ini_1_1IniItem.html#ad6dcf43f8615fdbd92a40dd7a6621f62',1,'Nini.Ini.IniItem.Name()'],['../classNini_1_1Ini_1_1IniReader.html#adb1e8905d5040bd8d7d61daad3616cae',1,'Nini.Ini.IniReader.Name()'],['../classNini_1_1Ini_1_1IniSection.html#a7fa3bdcacd6d4810a210ec0c85e209d2',1,'Nini.Ini.IniSection.Name()']]]
];
