var searchData=
[
  ['ignorecomments_0',['IgnoreComments',['../classNini_1_1Ini_1_1IniReader.html#a3169928d07397f73c2f58abef39dfc42',1,'Nini::Ini::IniReader']]],
  ['indentation_1',['Indentation',['../classNini_1_1Ini_1_1IniWriter.html#a4ad37821633b32200fbe8b16d1d9e59b',1,'Nini::Ini::IniWriter']]],
  ['instance_2',['Instance',['../classNini_1_1Env_1_1EnvMap.html#a588a73197809c1989e9d033444582b13',1,'Nini::Env::EnvMap']]],
  ['isfixedsize_3',['IsFixedSize',['../classNini_1_1Config_1_1ConfigCollection.html#a559548a3c6c680e69822c5194e194308',1,'Nini.Config.ConfigCollection.IsFixedSize()'],['../classNini_1_1Util_1_1OrderedList.html#ae12430c763981c537f2df7d5d77385be',1,'Nini.Util.OrderedList.IsFixedSize()']]],
  ['isreadonly_4',['IsReadOnly',['../classNini_1_1Config_1_1ConfigCollection.html#a335038141b3c5ba8b305f4df68a12f47',1,'Nini.Config.ConfigCollection.IsReadOnly()'],['../classNini_1_1Util_1_1OrderedList.html#acabb4e7435f5e3d357fa8d8ea8142e3d',1,'Nini.Util.OrderedList.IsReadOnly()']]],
  ['issynchronized_5',['IsSynchronized',['../classNini_1_1Config_1_1ConfigCollection.html#a267c26177aec4801165735a78b2541ce',1,'Nini.Config.ConfigCollection.IsSynchronized()'],['../classNini_1_1Ini_1_1IniSectionCollection.html#aed53004203992db5f22e06fcd8f2f2fa',1,'Nini.Ini.IniSectionCollection.IsSynchronized()'],['../classNini_1_1Util_1_1OrderedList.html#abce79c2437b4672f82f8a3a1b4a65720',1,'Nini.Util.OrderedList.IsSynchronized()']]],
  ['itemcount_6',['ItemCount',['../classNini_1_1Ini_1_1IniSection.html#a1f0baac49e76e0e3f300cd9ca82df152',1,'Nini::Ini::IniSection']]]
];
