var searchData=
[
  ['xmlconfigsource_0',['XmlConfigSource',['../classNini_1_1Config_1_1XmlConfigSource.html',1,'Nini::Config']]],
  ['xmlconfigsourcetests_1',['XmlConfigSourceTests',['../classNini_1_1Test_1_1Config_1_1XmlConfigSourceTests.html',1,'Nini::Test::Config']]]
];
