var searchData=
[
  ['namespacing_0',['Namespacing',['../namespaceNini_1_1Config.html#acec6f6cda46a176d202036251fe01d6eac2eafc39088c6121225cd7b36a014621',1,'Nini::Config']]],
  ['none_1',['None',['../namespaceNini_1_1Config.html#acec6f6cda46a176d202036251fe01d6ea6adf97f83acf6453d4a6a4b1070f3754',1,'Nini::Config']]]
];
